#include "TM1637.h"
#include "delay.h"
#include "stm32f4xx.h"   
 
const unsigned char SEGMENT_CODE[] = {0xbf,0x86,0xdb,0xcf,0xe6,0xed,0xfd,0x87,0xff,0xef};		//显示冒号的数码管段选
unsigned int delay_time = 10;
 
unsigned char disp_num[] = {0x3F, 0x06 | 0x80, 0x5B, 0x4F, 0x66, 0x6D};	
 
void TM1637_Init()
{
	GPIO_InitTypeDef GPIO_InitStruct;
	
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC,ENABLE);
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStruct.GPIO_OType= GPIO_OType_PP;
    GPIO_InitStruct.GPIO_Pin=GPIO_Pin_0 | GPIO_Pin_2;
    GPIO_InitStruct.GPIO_Speed=GPIO_High_Speed;
    GPIO_Init(GPIOC,&GPIO_InitStruct);
    
}
 
 
 
void TM1637_START()
{
  
        GPIO_CLK(1);
        delay_us(delay_time);
    
        GPIO_DIO(1);
        delay_us(delay_time);
    
        GPIO_DIO(0);
        delay_us(delay_time);
    
        GPIO_CLK(0);
        delay_us(delay_time);
            
}
 
 
void TM1637_STOP()
{
        
        GPIO_CLK(0);
        delay_us(delay_time);
    
        GPIO_DIO(0);
        delay_us(delay_time);
    
        GPIO_CLK(1);
        delay_us(delay_time);
    
        GPIO_DIO(1);
        delay_us(delay_time);
    
}
 
 
void TM1637_WRITE_BYTE_DATA(unsigned char mydata)
{
	unsigned char  i;

	for(i=0; i<8; i++)
	{
			GPIO_CLK(0);
			delay_us(delay_time);        
			
			GPIO_DIO(mydata & 0x01);
			
			delay_us(delay_time);
	
			GPIO_CLK(1);
			delay_us(delay_time);
	
			mydata >>= 1;
			delay_us(delay_time);
	
	}

	GPIO_CLK(0);
	delay_us(delay_time);
}
 
 
 
 
void TM1637_CHECK_ack()
{

	
	GPIO_CLK(0);
	delay_us(delay_time);

	while(GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_2)==1){}

	GPIO_CLK(1);
	delay_us(delay_time);
 
	GPIO_CLK(0);
	delay_us(delay_time);
}
 
 
 
/*写显示寄存器  地址自增*/

void TM1637_WRITE_DISPLAY_BYTE_FIX_ADDRESS(unsigned char addr, unsigned char my_data)
{
	unsigned char get_segment=0;

	TM1637_START(); 

	//写数据到显示寄存器 40H 地址自动加1 模式,44H 固定地址模式,本程序采用自加1模式
	TM1637_WRITE_BYTE_DATA(0x40+addr);
	TM1637_CHECK_ack();
	TM1637_STOP();
 
 
	TM1637_START();
	TM1637_WRITE_BYTE_DATA(0xC0+addr);
	TM1637_CHECK_ack();

 
	get_segment =  SEGMENT_CODE[my_data];
	TM1637_WRITE_BYTE_DATA(get_segment);
	TM1637_CHECK_ack(); 
	TM1637_STOP();    


	TM1637_START(); 
	TM1637_WRITE_BYTE_DATA(0X8C);             
	TM1637_CHECK_ack(); 
	TM1637_STOP();
}


