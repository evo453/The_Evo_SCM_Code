#include "stm32f4xx.h" 
#include "Timer.h"

//定时器3初始化函数
void TIM3_Init(void)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	//使能定时器3硬件时钟
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
	
	//配置定时器3分频值、计数值
	TIM_TimeBaseStructure.TIM_Period = 10000 / 2 - 1;			//计数值500ms
	TIM_TimeBaseStructure.TIM_Prescaler = 8400 - 1;				//进行8400的预分频值 42*2Mhz/8400=10000hz 10000次计数就是1秒
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;				//在f407不支持，没有时钟分频
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;//向上计数
	
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
	
	//配置定时器3中断的触发方式
	TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);

	//配置定时器3的中断优先级
	NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	//使能定时器3工作
	TIM_Cmd(TIM3, ENABLE);
}

