#ifndef __OLED_H__
#define __OLED_H__

#include "stm32f4xx.h"    
#include "stdlib.h"	

#define OLED_MODE 	0
#define SIZE 		8
#define XLevelL		0x00
#define XLevelH		0x10
#define Max_Column	128
#define Max_Row		64
#define	Brightness	0xFF 
#define X_WIDTH 	128
#define Y_WIDTH 	64	  



void OLED_Init(void);																		//OLED初始化
void OLED_ShowChar(uint8_t X, uint8_t Y, uint8_t Char, uint8_t Char_Size);					//显示一个字符
void OLED_ShowNum(uint8_t X, uint8_t Y, uint32_t Number, uint8_t Length, uint8_t size);		//显示数字
void OLED_ShowString(uint8_t X, uint8_t Y, uint8_t *String, uint8_t Char_Size);				//显示字符串
void OLED_ShowChinese(uint8_t X, uint8_t Y, uint8_t add);									//显示汉字
void OLED_DrawBMP(uint8_t X0, uint8_t X1, uint8_t Y0, uint8_t Y1, uint8_t BMP[]);			//显示图片

#endif
