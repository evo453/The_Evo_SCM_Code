#ifndef __USART_H__
#define __USART_H__

#include "io_bit.h" 
#include "stdio.h"
#include "string.h"
#include "stm32f4xx.h"   

typedef struct
{
	unsigned char RxBuff[256];//接收缓冲区 最大256
	unsigned char RecFlag;    //接收完成标志 为1接收到数据
	unsigned short RecLen;	  //接收到的长度
	
}USART1_TypeDef;

extern USART1_TypeDef Usart1;

void uart_init(u32 bound);
void USART_SendByte(uint8_t Byte);						//发送一个字节
void USART_SendArray(uint8_t *Array,uint16_t Length);	//发送一个数组
void USART_SendString(uint8_t *String);
void USART_SendNumber(uint32_t Number, uint8_t Length);

void Usart1_SendString(unsigned char *str);								//USART1发送字符串函数
void Usart1_SendPackage(unsigned char *data, unsigned short len);       //USART1数据包发送函数


#endif


