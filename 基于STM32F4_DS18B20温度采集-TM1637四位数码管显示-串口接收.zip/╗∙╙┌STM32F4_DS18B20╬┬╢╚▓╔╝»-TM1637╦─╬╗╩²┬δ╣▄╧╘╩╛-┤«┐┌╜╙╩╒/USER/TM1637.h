#ifndef __TM1637_H__
#define __TM1637_H__ 
 
#include "stm32f4xx.h"

#define    GPIO_CLK(x)      GPIO_WriteBit(GPIOC, GPIO_Pin_0, (BitAction)(x)); //CLK
#define    GPIO_DIO(x)      GPIO_WriteBit(GPIOC, GPIO_Pin_2, (BitAction)(x)); //DIO
 
 
void TM1637_Init(void);
 
void TM1637_START(void);
void TM1637_STOP(void); 
 
void TM1637_WRITE_BYTE_DATA(unsigned char mydata);
void TM1637_CHECK_ack(void);
 
 
void TM1637_WRITE_DISPLAY_BYTE_FIX_ADDRESS(unsigned char addr, unsigned char my_data);
 
            
#endif




