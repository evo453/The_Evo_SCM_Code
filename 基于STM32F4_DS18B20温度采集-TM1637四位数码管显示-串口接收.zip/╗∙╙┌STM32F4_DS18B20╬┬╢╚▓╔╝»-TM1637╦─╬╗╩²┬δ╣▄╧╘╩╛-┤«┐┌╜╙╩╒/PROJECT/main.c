#include "stm32f4xx.h"                 
#include "io_bit.h"
#include "USART.h"
#include "DS18B20.h"
#include "delay.h"
#include "TM1637.h"
#include "OLED.h"
#include "Timer.h"
#include "stdio.h"

///////////////////////////////////////
//		由于使用的开发板系统晶振为8MHz的晶振，需到（stm32f10x.h）文件中修改外部时钟频率
//		————>使用快捷键ctrl+G 输入123 跳转到该宏定义处

//		#if !defined  (HSE_VALUE) 
// 			 #define HSE_VALUE    ((uint32_t)8000000) /*!< Value of the External oscillator in Hz */
//  
//		#endif /* HSE_VALUE 

//		将((uint32_t)8000000)内的数修改成对应晶振时钟频率

/////////////////////////////////////////

/////////////////////////////////////////
//		
//		TM1637		CLK 引脚接 PC0
//					DIO 引脚接 PC2

//		DS18B20		DQ  引脚接 PB6

//		串口		RXD 引脚接 PA9
//					TXD	引脚接 PA10
////////////////////////////////////////
		
float temp_data;
int integer, decimals;

unsigned char tempHexstr_High1[2];
unsigned char tempHexstr_High2[2];
unsigned char tempHexstr_Low1[2];
unsigned char tempHexstr_Low2[2];


/*DS18B20温度读取并转换*/
void DS18B20_Temp(void)
{
	int temp;
	temp_data = DS18B20_Get_Temp();
	temp = temp_data * 100;
	integer = temp / 100;
	decimals = temp % 100;
}

///*OLED显示文字*/
//void OLED_Display(void)
//{
//	OLED_ShowChinese(0, 0, 0);
//	OLED_ShowChinese(16, 0, 1);
//	OLED_ShowChinese(32, 0, 2);
//	OLED_ShowChinese(48, 0, 3);
//	OLED_ShowString(64,0, ":", 16);
//	OLED_ShowString(16,2, ".", 16);
//	OLED_ShowChinese(40, 2, 4);
//}

/**************十进制数转十六进制字符*****************/
void nToHexstr(unsigned char n, unsigned char *Hexstr, unsigned char strlen)
{
	unsigned char HexChar[10] = {'0','1','2','3','4','5','6','7','8','9'}; 
	unsigned char i;
	unsigned char dis;
	unsigned long nTemp = (long) n;
	for(i = 1; i <= strlen; i++)
	{
		dis = nTemp & 0x0F;						// 0000 0011 nTemp & 0000 1111		28  0010 1000
		Hexstr[strlen-i] = HexChar[dis]; 		//  hexstr
		nTemp = nTemp >> 4;
	}
		Hexstr[strlen] = '\0';
}


int main()
{	
	TM1637_Init(); 
	DS18B20_Init();
	uart_init(9600);
//	OLED_Init();
	TIM3_Init();
		
//	OLED_Display();
	

	
	while(1)
	{
		
		/*DS18B20温度读取并转换*/
		DS18B20_Temp();

		/*数码管显示驱动*/
		//此函数必须执行4次，才能将数据写入缓冲器				
		TM1637_WRITE_DISPLAY_BYTE_FIX_ADDRESS(0, integer / 10);
		TM1637_WRITE_DISPLAY_BYTE_FIX_ADDRESS(1, integer % 10);
		TM1637_WRITE_DISPLAY_BYTE_FIX_ADDRESS(2, decimals / 10);
		TM1637_WRITE_DISPLAY_BYTE_FIX_ADDRESS(3, decimals % 10);
		
		/***转换温度数字后的字符***/
		nToHexstr((unsigned char)integer / 10, tempHexstr_High1, 1);
		nToHexstr((unsigned char)integer % 10, tempHexstr_High2, 1);
		nToHexstr((unsigned char)decimals / 10, tempHexstr_Low1, 1);
		nToHexstr((unsigned char)decimals % 10, tempHexstr_Low2, 1);
	}
}

/**************定时器中断***************/
void TIM3_IRQHandler(void)
{
	//判断标志位
	if(TIM_GetITStatus(TIM3,TIM_IT_Update)==SET)
	{
//		OLED_ShowNum(0, 2, integer, 2, 16);
//		OLED_ShowNum(24, 2, decimals, 2,16);
		
		/***发送到串口助手的数据***/
		printf("temperature: ");
		printf(&tempHexstr_High1[0]);
		printf(&tempHexstr_High2[0]);
		printf(".");
		printf(&tempHexstr_Low1[0]);
		printf(&tempHexstr_Low2[0]);
		printf("'C\r\n");
		/**************************/
		
		//清空标志位
		TIM_ClearITPendingBit(TIM3,TIM_IT_Update);
	}
}
