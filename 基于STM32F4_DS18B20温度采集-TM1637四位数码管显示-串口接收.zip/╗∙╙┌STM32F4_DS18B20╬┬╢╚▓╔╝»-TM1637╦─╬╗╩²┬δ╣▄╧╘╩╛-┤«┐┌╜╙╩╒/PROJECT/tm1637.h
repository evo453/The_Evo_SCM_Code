#ifndef __TM1637_H__
#define __TM1637_H__ 
 
#include "stm32f4xx.h"

#define    GPIO_CLK(x)      GPIO_WriteBit(GPIOB, GPIO_Pin_0, (BitAction)(x)); //CLK
#define    GPIO_DIO(x)      GPIO_WriteBit(GPIOB, GPIO_Pin_1, (BitAction)(x)); //DIO
 
 
void TM1637_Init(void);
 
void TM1637_START(void);
void TM1637_STOP(void);                 //结束条件
 
void TM1637_WRITE_BYTE_DATA(unsigned char mydata);
void TM1637_CHECK_ack(void);
 
 
void TM1637_WRITE_DISPLAY_BYTE_FIX_ADDRESS(unsigned char addr, unsigned char my_data);
 
            
#endif




