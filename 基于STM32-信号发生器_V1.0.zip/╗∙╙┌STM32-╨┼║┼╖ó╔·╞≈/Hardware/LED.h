#ifndef __LED_H__
#define __LED_H__

void LED_Init(void);
void LED_Red_ON(void);
void LED_Green_ON(void);
void LED_Red_OFF(void);
void LED_Green_OFF(void);
void LED_Red_Turn(void);
void LED_Green_Turn(void);

#endif
