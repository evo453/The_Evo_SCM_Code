#include "stm32f10x.h"                  // Device header

void Encoder_Init(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);					//TIM3是APB1总线的外设
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);				//打开GPIOA的时钟
	
	GPIO_InitTypeDef GPIO_InitStructure;								//定义PB引脚的结构体
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;						//IPU上拉输入模式
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;				//选择6.7号引脚
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;					//速度选择50MHz
	GPIO_Init(GPIOA,&GPIO_InitStructure);								//GPIO初始化.使用PA总线
		
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;			//指定时钟分频
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;	    //计数器模式->向上计数\向下计数\中央对齐
	TIM_TimeBaseInitStructure.TIM_Period = 65535-1;						//ARR 自动重装器的值（0-65535）
	TIM_TimeBaseInitStructure.TIM_Prescaler = 1-1;						//PSC 预分频器的值（0-65535）
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;				//（高级定时器专有）重复计数器的值
	// 定时频率 = 72M /（PSC+1）/（ARR+1）
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseInitStructure);					//初始化时基单元
	
	TIM_ICInitTypeDef TIM_ICInitStructure;
	TIM_ICStructInit(&TIM_ICInitStructure);								//设置默认初始值，防止未配置的结构体单元因不确定值出问题
	TIM_ICInitStructure.TIM_Channel = TIM_Channel_1;					//指定IC输入捕获的通道
	TIM_ICInitStructure.TIM_ICFilter = 0xF;								//选择输入捕获的滤波器
	TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;			//极性.编码器高低电平极性不反转
	TIM_ICInit(TIM3,&TIM_ICInitStructure);								//输入捕获通道初始化
	
	TIM_ICInitStructure.TIM_Channel = TIM_Channel_2;					//指定IC输入捕获的通道
	TIM_ICInitStructure.TIM_ICFilter = 0xF;								//选择输入捕获的滤波器
	TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;			//极性.编码器高低电平极性不反转
	TIM_ICInit(TIM3,&TIM_ICInitStructure);								//输入捕获通道初始化

	
	TIM_EncoderInterfaceConfig(TIM3,TIM_EncoderMode_TI12,TIM_ICPolarity_Rising,TIM_ICPolarity_Rising);			//编码器接口配置,任一极性设置反转，记增减的方向翻转
	
	TIM_Cmd(TIM3,ENABLE);
}

int16_t Encoder_Get(void)
{
	int16_t Temp;
	Temp = TIM_GetCounter(TIM3);
	return Temp;										//返回CNT计数的值
}

