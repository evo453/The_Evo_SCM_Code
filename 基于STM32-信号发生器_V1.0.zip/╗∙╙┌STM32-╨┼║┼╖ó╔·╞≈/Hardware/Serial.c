#include "stm32f10x.h"                  // Device header
#include <stdio.h>
#include <stdarg.h>

uint8_t Serial_TxPacket[10];				//定义发送缓存数组
uint8_t Serial_RxPacket[10];				//定义接收缓存数组
uint8_t Serial_RxFlag;

void Serial_Init(void)
{
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);							//开启UASRT2的时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);							//开启GPIO的时钟

	GPIO_InitTypeDef GPIO_InitStructure;								//定义PA引脚的结构体
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;						//AF_PP.复用推挽输出模式
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;							//选择2号引脚
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;					//速度选择50MHz
	GPIO_Init(GPIOA,&GPIO_InitStructure);								//GPIO初始化.使用PA总线
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;						//IPU上拉输入模式
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;							//选择3号引脚
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;					//速度选择50MHz
	GPIO_Init(GPIOA,&GPIO_InitStructure);								//GPIO初始化.使用PA总线
	
	USART_InitTypeDef USART_InitStructure;
	USART_InitStructure.USART_BaudRate = 9600;										//波特率
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;	//硬件流控制
	USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;					//同时开启发送/接收模式
	USART_InitStructure.USART_Parity = USART_Parity_No;								//校验位
	USART_InitStructure.USART_StopBits = USART_StopBits_1;							//停止位
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;						//字长
	USART_Init(USART2,&USART_InitStructure);
	
	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);									//开启RXNE标志位到NVIC的输出
	
//	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);									//配置优先级分组:抢占(先占)优先级和响应(从占)优先级
//	
//	NVIC_InitTypeDef NVIC_InitStructure;
//	NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;								//中断通道
//	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;									//指定中断通道使能还是失能
//	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 4;						//指定所选中断通道的抢占优先级
//	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;								//指定所选中断通道的响应优先级
//	NVIC_Init(&NVIC_InitStructure);
	
	USART_Cmd(USART2,ENABLE);										//USART2使能
}

void Serial_SendByte(uint8_t Byte)									//发送一个字节
{
	USART_SendData(USART2, Byte);
	while(USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);	//获取标志位 ->	TXE发送数据寄存器空标志位,等待发送完成
}

void Serial_SendArray(uint8_t *Array,uint16_t Length)				//发送一个数组
{
	uint16_t i;
	for(i = 0 ;i < Length ; i++)
	{
		Serial_SendByte(Array[i]);
	}
}

void Serial_SendString(uint8_t *String)								//发送一个字符串
{
	uint8_t i;
	for(i = 0; String[i] != '\0'; i++)
	{
		Serial_SendByte(String[i]);
	}
}

uint32_t Serial_Pow(uint32_t X, uint32_t Y)
{
	uint32_t Result = 1;
	while(Y--)
	{
		Result *= X;
	}
	return Result;
}

void Serial_SendNumber(uint32_t Number, uint8_t Length)				//发送
{
	uint8_t i;
	for(i = 0; i < Length ;i++)
	{
		Serial_SendByte(Number / Serial_Pow(10, Length - 1 - i) % 10 + '0');
	}
}

int fputc(int ch, FILE *f)
{
	Serial_SendByte(ch);
	return ch;
}

void Serial_Printf(char *format, ...)
{
	char String[100];
	va_list arg;
	va_start(arg, format);
	vsprintf(String, format, arg);
	va_end(arg);
	Serial_SendString((uint8_t *)String);
}


/*中断接收*/
uint8_t Serial_GetRxFlag(void)								//读取后自动清除标志位
{
	if(Serial_RxFlag == 1)
	{
		Serial_RxFlag =0;
		return 1;
	}
	return 0;
}


//void USART2_IRQHandler(void)								//中断接收
//{
//	static uint8_t RxState = 0;								//定义局部静态状态变量
//	static uint8_t pRxPacket = 0;							//定义局部静态接收指示变量
//	
//		if(USART_GetFlagStatus(USART2, USART_IT_RXNE) == SET)		//接受标志位判断
//		{
//			uint8_t RxData = USART_ReceiveData(USART2);
//			
//			if(RxState == 0)								//状态0 -> 等待包头
//			{
//				if(RxData == 0xFF)
//				{
//					RxState = 1;
//					pRxPacket = 0;
//				}
//			}
//				else if(RxState == 1)							//状态1 -> 等待数据接收
//				{
//					Serial_RxPacket[pRxPacket] = RxData;
//					pRxPacket++;
//					if(pRxPacket >= 4)
//					{
//						RxState = 2;
//					}
//				}
//					else if(RxState == 2)							//状态2 -> 等待包尾
//					{
//						if(RxData == 0xFE)
//						{
//							RxState = 0;
//							Serial_RxFlag = 1;
//						}
//					}
//			
//			USART_ClearITPendingBit(USART2, USART_IT_RXNE);							//清除标志位
//		}
//}
/*********/



/**发送Hex数据包**/
void Serial_SendPacket(void)
{
	Serial_SendByte(0xFF);						//发送包头0xFF
	Serial_SendArray(Serial_TxPacket, 8);		//发送载荷数据包
	Serial_SendByte(0xFE);						//发送包头0xFE
}


/***************/


