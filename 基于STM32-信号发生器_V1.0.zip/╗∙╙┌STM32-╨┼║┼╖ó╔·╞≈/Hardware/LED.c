#include "stm32f10x.h"                  // Device header

void LED_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);				//打开GPIOB的时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE,ENABLE);				//打开GPIOE的时钟
	
	GPIO_InitTypeDef GPIO_InitStructureB;								//定义PB引脚的结构体
	GPIO_InitTypeDef GPIO_InitStructureE;								//定义PE引脚的结构体
	
	GPIO_InitStructureB.GPIO_Mode = GPIO_Mode_Out_PP;					//OUT_PP.推挽输出模式
	GPIO_InitStructureB.GPIO_Pin = GPIO_Pin_5;							//选择5号引脚
	GPIO_InitStructureB.GPIO_Speed = GPIO_Speed_50MHz;					//速度选择50MHz
	GPIO_Init(GPIOB,&GPIO_InitStructureB);								//GPIO初始化.使用PB总线
	
	GPIO_InitStructureE.GPIO_Mode = GPIO_Mode_Out_PP;					//OUT_PP.推挽输出模式
	GPIO_InitStructureE.GPIO_Pin = GPIO_Pin_5;							//选择5号引脚
	GPIO_InitStructureE.GPIO_Speed = GPIO_Speed_50MHz;					//速度选择50MHz
	GPIO_Init(GPIOE,&GPIO_InitStructureE);								//GPIO初始化.使用PE总线
	
	GPIO_SetBits(GPIOB,GPIO_Pin_5);										//设置该引脚初始化后为高电平
	GPIO_SetBits(GPIOE,GPIO_Pin_5);										//设置该引脚初始化后为高电平
}

void LED_Red_ON(void)
{
	GPIO_ResetBits(GPIOB,GPIO_Pin_5);
}

void LED_Green_ON(void)
{
	GPIO_ResetBits(GPIOE,GPIO_Pin_5);
}

void LED_Red_OFF(void)
{
	GPIO_SetBits(GPIOB,GPIO_Pin_5);
}

void LED_Green_OFF(void)
{
	GPIO_SetBits(GPIOE,GPIO_Pin_5);
}

void LED_Red_Turn(void)
{
	if(GPIO_ReadOutputDataBit(GPIOB,GPIO_Pin_5) == 0)
	{
		GPIO_SetBits(GPIOB,GPIO_Pin_5);
	}
	else
	{
		GPIO_ResetBits(GPIOB,GPIO_Pin_5);
	}
}

void LED_Green_Turn(void)
{
	if(GPIO_ReadOutputDataBit(GPIOE,GPIO_Pin_5) == 0)
	{
		GPIO_SetBits(GPIOE,GPIO_Pin_5);
	}
	else
	{
		GPIO_ResetBits(GPIOE,GPIO_Pin_5);
	}
}
