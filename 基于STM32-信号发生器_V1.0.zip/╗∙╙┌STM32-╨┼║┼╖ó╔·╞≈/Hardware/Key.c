#include "stm32f10x.h"                  // Device header
#include "Delay.h"

uint8_t KeyNum = 0;												//按键键码默认为0

void Key_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE,ENABLE);			//打开GPIOE的时钟
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;						//Mode_IPU.上拉输入
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_6;	//使用了PE3.PE4.PE6.IO口
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;					//该参数为GPIO的输出速度，输入状态下无影响，随便选
	GPIO_Init(GPIOE,&GPIO_InitStructure);								//GPIO初始化.使用PE总线
	
	KeyNum = 0;
}

uint16_t Key_GetNum(void)											//unsigned char == uint8_t
{

	if(GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_3) == 0)				//使用函数读取是否有按键按下->按键按下接地，读取为低电平
	{
		Delay_ms(20);												//按键消抖
		while(GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_3) == 0);		//不松手一直卡死在读取按键状态下
		Delay_ms(20);												
		KeyNum = 1;													//将键码返回1	
	}
	
	if(GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_4) == 0)				//使用函数读取是否有按键按下->按键按下接地，读取为低电平
	{
		Delay_ms(20);												//按键消抖
		while(GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_4) == 0);		//不松手一直卡死在读取按键状态下
		Delay_ms(20);												
		KeyNum = 2;													//将键码返回2	
	}
	
	if(GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_6) == 0)				//使用函数读取是否有按键按下->按键按下接地，读取为低电平
	{
		Delay_ms(20);												//按键消抖
		while(GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_6) == 0);		//不松手一直卡死在读取按键状态下
		Delay_ms(20);												
		KeyNum = 3;													//将键码返回3	
	}
	
	return KeyNum;
}
