#ifndef __ENCODER_H__
#define __ENCODER_H__

void Encoder_Init(void);
int16_t Encoder_Get(void);

#endif


