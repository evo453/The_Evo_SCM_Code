#include "stm32f10x.h"                  // Device header


void PWM_Init(uint16_t ARR, uint16_t PSC,uint16_t CCR)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);					//TIM2是APB1总线的外设
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);				//打开GPIOA的时钟
	
	
	GPIO_InitTypeDef GPIO_InitStructure;								//定义PA引脚的结构体
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;						//AF_PP.复用推挽输出模式,将IO口的控制权交给片上外设(TIM),PWM才能通过IO口输出
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;							//选择1号引脚
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;					//速度选择50MHz
	GPIO_Init(GPIOA,&GPIO_InitStructure);								//GPIO初始化.使用PA总线
	
	TIM_InternalClockConfig(TIM2);										//选择TIM2时基单元由内部时钟驱动，如果不写，默认使用内部时钟
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;			//指定时钟分频	
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;	    //计数器模式->向上计数\向下计数\中央对齐
	TIM_TimeBaseInitStructure.TIM_Period = ARR-1;						//ARR 自动重装器的值（0-65535）9
	TIM_TimeBaseInitStructure.TIM_Prescaler = PSC-1;	 				//PSC 预分频器的值（0-65535）1
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;				//（高级定时器专有）重复计数器的值
	// 定时频率 = 72M /（PSC+1）/（ARR+1）
	TIM_TimeBaseInit(TIM2,&TIM_TimeBaseInitStructure);					//初始化时基单元
	
	TIM_OCInitTypeDef TIM_OCInitstrucrure;
	TIM_OCStructInit(&TIM_OCInitstrucrure);
	TIM_OCInitstrucrure.TIM_OCMode = TIM_OCMode_PWM1;					//设置输出比较的模式
	TIM_OCInitstrucrure.TIM_OCPolarity = TIM_OCPolarity_High;			//设置输出比较的极性		
	TIM_OCInitstrucrure.TIM_OutputState = TIM_OutputState_Enable;		//设置输出使能
	TIM_OCInitstrucrure.TIM_Pulse = CCR  ;								//CCR 设置
	TIM_OC2Init(TIM2,&TIM_OCInitstrucrure); 							//初始化TIM2通道2				

	
	TIM_Cmd(TIM2,ENABLE);												//定时器控制

}

void PWM_SetCompare2(uint16_t CCR)
{
	TIM_SetCompare2(TIM2,CCR);											//设置通道2输入捕获的值CCR
}

void TIM_SetPerscler(uint16_t PSC)					
{
	TIM_PrescalerConfig(TIM2,PSC,TIM_PSCReloadMode_Update);				//配置TIM2预分频器的值PSC
}

void TIM_MySetAutoreload(uint16_t ARR)
{
	TIM_SetAutoreload(TIM2,ARR);										//配置TIM自动重装值ARR
}


uint16_t TIM_GetCounter(TIM_TypeDef* TIMx);
//获取当前计数器的值，如果想看当前计数器计到哪里了就可调用此函数，
//返回值就是当前计数器的值
uint16_t TIM_GetPrescaler(TIM_TypeDef* TIMx);
//获取当前预分频器的值
FlagStatus TIM_GetFlagStatus(TIM_TypeDef* TIMx, uint16_t TIM_FLAG);
void TIM_ClearFlag(TIM_TypeDef* TIMx, uint16_t TIM_FLAG);
ITStatus TIM_GetITStatus(TIM_TypeDef* TIMx, uint16_t TIM_IT);
void TIM_ClearITPendingBit(TIM_TypeDef* TIMx, uint16_t TIM_IT);
//这四个函数用来获取标志位和清楚位的
void TIM_SetCounter(TIM_TypeDef* TIMx, uint16_t Counter);
//给计数器写入一个值，如果想手动给一个计数值就可调用此函数，
