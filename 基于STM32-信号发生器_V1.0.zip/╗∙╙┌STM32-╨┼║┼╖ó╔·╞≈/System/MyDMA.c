#include "stm32f10x.h"                  // Device header

static uint16_t MyDMA_Size;				//定义传输计数器重新赋值大小的全局变量

void MyDMA_Init(uint32_t AddrA, uint32_t AddrB, uint16_t Size)
{
	MyDMA_Size = Size;					//将获取的计数大小存到全局变量用以传输计数器重新赋值
	
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1,ENABLE);								//DMA是AHB总线的设备
	//DMA触发有三个条件：1.传输计数器大于0	2.触发源有触发信号	3.DMA使能
	
	DMA_InitTypeDef DMA_InitStructure;
	DMA_InitStructure.DMA_PeripheralBaseAddr = AddrA;						//uint32_t的外设站点的基地址，对于SRAM的数组，由编译器分配，并非固定，一般不写绝对地址，通过数组名获取地址
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;	//外设数据宽度 -> 字节/半字/字
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Enable;			//指定外设地址是否自增
	DMA_InitStructure.DMA_MemoryBaseAddr = AddrB;							//存储器站点的基地址，与外设站点一样，通过数组名获取地址
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;			//存储器数据宽度 -> 字节/半字/字
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;					//指定存储器地址是否自增
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;						//指定外设站点是源端还是目的地
	DMA_InitStructure.DMA_BufferSize = Size;								//以数据单元，指定缓存区大小，即传输计数器大小
	DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;							//指定传输计数器是否要自动重装
	DMA_InitStructure.DMA_M2M = DMA_M2M_Enable;								//DMA是否应用于存储器到存储器的转运（软件触发）
	DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;					//指定通道的软件优先级
	DMA_Init(DMA1_Channel7,&DMA_InitStructure);								//1.选择哪个DMA，通道几
	
	DMA_Cmd(DMA1_Channel7,ENABLE);											//DMA使能
	
}

void MyDMA_Transfer(void)													//再次启动DMA转运
{
	DMA_Cmd(DMA1_Channel7,DISABLE);											//DMA失能
	DMA_SetCurrDataCounter(DMA1_Channel7,MyDMA_Size);						//传输计数器重新赋值
	DMA_Cmd(DMA1_Channel7,ENABLE);											//DMA使能
	
	while(DMA_GetFlagStatus(DMA1_FLAG_TC1) == RESET);						//查看转运标志位 -> 1.全局标志位 2.转运完成标志位 3.转运过半标志位 4.转运错误标志位
	//转运完成标志位置1，while等待标志位完成
	DMA_ClearFlag(DMA1_FLAG_TC1);											//手动清除标志位
}


