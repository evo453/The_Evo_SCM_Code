#ifndef __PWM_H__
#define __PWM_H__

void PWM_Init(uint16_t ARR, uint16_t PSC,uint16_t CCR);
void PWM_SetCompare2(uint16_t CCR);
void TIM_SetPerscler(uint16_t PSC);
void TIM_MySetAutoreload(uint16_t ARR);

#endif
