#ifndef __STATE_H__
#define __STATE_H__

extern uint16_t TIM2_ARR;										//TIM2 ARR的值
extern uint16_t TIM2_PSC;										//TIM2 PSC的值
extern uint16_t TIM2_CCR;										//TIM2 CCR的值

void State_run(uint16_t Count);
void Duty_cut(uint16_t Count);

#endif

