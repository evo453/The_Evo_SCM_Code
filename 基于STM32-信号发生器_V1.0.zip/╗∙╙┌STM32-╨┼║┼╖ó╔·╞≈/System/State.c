#include "stm32f10x.h"                  		// Device header
#include "PWM.h"
#include "Encoder.h"
#include "Key.h"

uint8_t State;									//状态机标志位
uint8_t State_Flag;								//状态切换判断标志位
uint8_t Duty_Freq;								//占空比/频率切换标志位
uint8_t State_Aided;							//状态切换辅助标志位

uint16_t Temp;									//频率/占空比切换当前计数存储值
uint16_t Duty_Count;							//占空比计数值
uint16_t TIM2_ARR;								//TIM2 ARR的值
uint16_t TIM2_PSC;								//TIM2 PSC的值
uint16_t TIM2_CCR;								//TIM2 CCR的值

//enum 
//{
//	percent_zero,
//	percent_ten,
//	percent_twenty,
//	percent_thirty,
//	percent_fourty,
//	percent_fifty,
//	percent_sixty,
//	percent_seventy, 
//	percent_eighty,
//	percent_ninty,
//	percent_hunder,
//	
//} Duty_percent;									//占空比百分比调节

void Duty_cut(uint16_t Count);

void State_run(uint16_t Count)
{
		Duty_Count = Count;
	
		if(State == 0)
		{
//			TIM_MySetAutoreload(Count + 9);
//			PWM_SetCompare2((Count+9) / 2);		
//			TIM_MySetAutoreload(80 - Count * 2);
//			PWM_SetCompare2((80 - Count * 2) / 2);
			
			Duty_cut(Duty_Count);
			
			if(Duty_Freq == 0)					//调频
			{
				TIM_MySetAutoreload(80 - Count * 2);
					PWM_SetCompare2((80 - Count * 2) / 2);
			}
		}
		
		
		
/**1KHz**/
		if(Key_GetNum() == 1 && State == 0)
		{
			Key_Init();
				TIM_SetCounter(TIM3,0);				//计数清零
					State = 1;
				if(State_Flag == 0)				//PWM初始化标志位
				{
					PWM_Init(72,1000,36);
						State_Flag = 1;
				}
		}
		
		if(State == 1)							
		{
			Duty_cut(Duty_Count);
			
			if(Duty_Freq == 0)					//调频
			{
				TIM_MySetAutoreload(Count + 72);
					PWM_SetCompare2((Count + 72) / 2);
			}
		}
/**1KHz**/	
		
		
		
/**90Hz**/
		if(Key_GetNum() == 1 && State == 1)
		{
			Key_Init();
				TIM_SetCounter(TIM3,0);				//计数清零
					State = 2;
			if(State_Flag == 1)					//PWM初始化标志位
			{
				PWM_Init(1110,720,555);
					State_Flag = 2;
			}
		}
		
		if(State == 2)						
		{
			Duty_cut(Duty_Count);
			
			if(Duty_Freq == 0)					//调频
			{
				TIM_MySetAutoreload(Count + 1110);
					PWM_SetCompare2((Count + 1110) / 2);
			}
		}
/**90Hz**/
		
		
/**11Hz**/
		if(Key_GetNum() == 2 && State == 2)
		{
			Key_Init();
				TIM_SetCounter(TIM3,0);				//计数清零
					State = 3;
			if(State_Flag == 2)					//PWM初始化标志位
			{
				PWM_Init(110,60000,55);
					State_Flag = 3;
			}
		}
		if(State == 3)						
		{
			Duty_cut(Duty_Count);
			
			if(Duty_Freq == 0)					//调频
			{
				TIM_MySetAutoreload(Count + 110);
					PWM_SetCompare2((Count + 110) / 2);
			}
		}
/**11Hz**/
		
		
		
/**1Hz**/
		if(Key_GetNum() == 2 && State == 3)
		{
			Key_Init();
				TIM_SetCounter(TIM3,0);				//计数清零
					State = 4;
			if(State_Flag == 3)					//PWM初始化标志位
			{
				PWM_Init(1200,60000,55);
					State_Flag = 4;
			}
		}
		if(State == 4)							
		{
			Duty_cut(Duty_Count);
		
			if(Duty_Freq == 0)					//调频
			{
				TIM_MySetAutoreload(Count*1000 + 1200);
					PWM_SetCompare2((Count*1000 + 1200) / 2);
			}
		}
/**1Hz**/
		
		
/*****占空比调节*****/
	if(Duty_Freq == 1)
	{	
		TIM_ARRPreloadConfig(TIM2,DISABLE);
			if(Count > 50)TIM_SetCounter(TIM3,0);
				switch(Count)
				{
					case 0:  TIM2_CCR = TIM2_ARR / 25 * 0 ;break;
					case 1:  TIM2_CCR = TIM2_ARR / 25 * 1 ;break;
					case 2:  TIM2_CCR = TIM2_ARR / 25 * 2 ;break;
					case 3:  TIM2_CCR = TIM2_ARR / 25 * 3 ;break;
					case 4:  TIM2_CCR = TIM2_ARR / 25 * 4 ;break;
					case 5:  TIM2_CCR = TIM2_ARR / 25 * 5 ;break;
					case 6:  TIM2_CCR = TIM2_ARR / 25 * 6 ;break;
					case 7:  TIM2_CCR = TIM2_ARR / 25 * 7 ;break;
					case 8:  TIM2_CCR = TIM2_ARR / 25 * 8 ;break;
					case 9:  TIM2_CCR = TIM2_ARR / 25 * 9 ;break;
					case 10: TIM2_CCR = TIM2_ARR / 25 * 10;break;
					case 11: TIM2_CCR = TIM2_ARR / 25 * 11;break;
					case 12: TIM2_CCR = TIM2_ARR / 25 * 12;break;
					case 13: TIM2_CCR = TIM2_ARR / 25 * 13;break;
					case 14: TIM2_CCR = TIM2_ARR / 25 * 14;break;
					case 15: TIM2_CCR = TIM2_ARR / 25 * 15;break;
					case 16: TIM2_CCR = TIM2_ARR / 25 * 16;break;
					case 17: TIM2_CCR = TIM2_ARR / 25 * 17;break;
					case 18: TIM2_CCR = TIM2_ARR / 25 * 18;break;
					case 19: TIM2_CCR = TIM2_ARR / 25 * 19;break;
					case 20: TIM2_CCR = TIM2_ARR / 25 * 20;break;
					case 21: TIM2_CCR = TIM2_ARR / 25 * 21;break;
					case 22: TIM2_CCR = TIM2_ARR / 25 * 22;break;
					case 23: TIM2_CCR = TIM2_ARR / 25 * 23;break;
					case 24: TIM2_CCR = TIM2_ARR / 25 * 24;break;
					case 25: TIM2_CCR = TIM2_ARR / 25 * 25;break;
					case 26: TIM2_CCR = TIM2_ARR / 25 * 26;break;
					case 27: TIM2_CCR = TIM2_ARR / 25 * 27;break;
					case 28: TIM2_CCR = TIM2_ARR / 25 * 28;break;
					case 29: TIM2_CCR = TIM2_ARR / 25 * 29;break;
					case 30: TIM2_CCR = TIM2_ARR / 25 * 30;break;
					case 31: TIM2_CCR = TIM2_ARR / 25 * 31;break;
					case 32: TIM2_CCR = TIM2_ARR / 25 * 32;break;
					case 33: TIM2_CCR = TIM2_ARR / 25 * 33;break;
					case 34: TIM2_CCR = TIM2_ARR / 25 * 34;break;
					case 35: TIM2_CCR = TIM2_ARR / 25 * 35;break;
					case 36: TIM2_CCR = TIM2_ARR / 25 * 36;break;
					case 37: TIM2_CCR = TIM2_ARR / 25 * 37;break;
					case 38: TIM2_CCR = TIM2_ARR / 25 * 38;break;
					case 39: TIM2_CCR = TIM2_ARR / 25 * 39;break;
					case 40: TIM2_CCR = TIM2_ARR / 25 * 40;break;
					case 41: TIM2_CCR = TIM2_ARR / 25 * 41;break;
					case 42: TIM2_CCR = TIM2_ARR / 25 * 42;break;
					case 43: TIM2_CCR = TIM2_ARR / 25 * 43;break;
					case 44: TIM2_CCR = TIM2_ARR / 25 * 44;break;
					case 45: TIM2_CCR = TIM2_ARR / 25 * 45;break;
					case 46: TIM2_CCR = TIM2_ARR / 25 * 46;break;
					case 47: TIM2_CCR = TIM2_ARR / 25 * 47;break;
					case 48: TIM2_CCR = TIM2_ARR / 25 * 48;break;
					case 49: TIM2_CCR = TIM2_ARR / 25 * 49;break;
					case 50: TIM2_CCR = TIM2_ARR / 25 * 50;break;
				}
				PWM_SetCompare2(TIM2_CCR);
	}
/*****占空比调节*****/
					
}


void Duty_cut(uint16_t Duty_Count)
{
	if(Key_GetNum() == 3 && Duty_Freq == 0)			//进入占空比调节
	{
		Key_Init();
			Duty_Freq = 1;								//切换为占空比调节
				TIM2_ARR = TIM2 -> ARR;						
				TIM2_PSC = TIM2 -> PSC;
				TIM2_CCR = TIM2_ARR / 2;
		if(TIM2_PSC == 0)TIM2_PSC = 1;
			Temp = Duty_Count;							//将当前调节值保存
				PWM_Init(TIM2_ARR,TIM2_PSC,TIM2_CCR);		//设定当前调频后的值
				TIM_SetCounter(TIM3,0);						//计数清零
	}
	
	if(Key_GetNum() == 3 && Duty_Freq == 1)			//退出占空比调节
	{			
		Key_Init();
			Duty_Freq = 0;								//切换为频率调节
				TIM2_ARR = TIM2 -> ARR;	
				TIM2_PSC = TIM2 -> PSC;
				TIM2_CCR = TIM2_ARR / 2;
		if(TIM2_PSC == 0)TIM2_PSC = 1;
			PWM_Init(TIM2_ARR,TIM2_PSC,TIM2_CCR);		//设定当前调频后的值
				TIM_SetCounter(TIM3,Temp);					//将先前保存的计数值调回
				Temp = 0;									//保存值清零
	}
}
