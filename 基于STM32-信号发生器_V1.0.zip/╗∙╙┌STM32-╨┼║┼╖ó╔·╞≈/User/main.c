#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "PWM.h"
#include "OLED.h"
#include "Encoder.h"
#include "Serial.h"
#include "Key.h"
#include "State.h"
#include "MyDMA.h"
#include "Timer.h"

extern uint8_t State_Flag;	
uint32_t Freq;
uint16_t Count;										//编码器变量

int main(void)
{
//	OLED_Init();
	PWM_Init(9,1,4);
	Timer_Init();
	Serial_Init();
	Encoder_Init();
	Key_Init();
	
	while(1)
	{
		
		Count = Encoder_Get();						//编码器计数
		State_run(Count);							//调频 调占空比
		
		TIM2_ARR = TIM2 -> ARR;
		TIM2_PSC = TIM2 -> PSC;
		
		if(TIM2_PSC == 0 || State_Flag)
		{
			TIM2_PSC = 1;
			Freq = 72000000 / TIM2_ARR /TIM2_PSC;
		}
	}
}

void TIM4_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM4,TIM_IT_Update) == SET)	//->查看中断口.更新中断标志位
	{
		Serial_SendNumber(Freq,8);					//串口发送
		Serial_SendString("\r\n");
		TIM_ClearITPendingBit(TIM4,TIM_IT_Update);
	}
}
